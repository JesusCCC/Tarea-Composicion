/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.descripcion;

/**
 *
 * @author arman
 */
public class Editorial {
    private String nombre;
    private String ubicacion;
    private int año;
    private boolean logo; //true = tiene logo

    //Constructor
    public Editorial() {
    }
 
    //Constructor sobrecargado
    public Editorial(String nombre, String ubicacion, int año, boolean logo) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.año = año;
        this.logo = logo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getAño() {
        return año;
    }

    public void setAño(int año) {
        this.año = año;
    }

    public boolean isLogo() {
        return logo;
    }

    public void setLogo(boolean logo) {
        this.logo = logo;
    }

    @Override
    public String toString() {
        return "Editorial{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", a\u00f1o=" + año + ", logo=" + logo + '}';
    }

   
}
