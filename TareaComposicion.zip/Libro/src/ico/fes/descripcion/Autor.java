/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.descripcion;

/**
 *
 * @author arman
 */
public class Autor {
    private String nombre;
    private boolean foto; // true=tiene la foto del autor

    //Constructor
    public Autor() {
    }

    //Constructor sobrecargado
    public Autor(String nombre, boolean foto) {
        this.nombre = nombre;
        this.foto = foto;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isFoto() {
        return foto;
    }

    public void setFoto(boolean foto) {
        this.foto = foto;
    }

    @Override
    public String toString() {
        return "Autor{" + "nombre=" + nombre + ", foto=" + foto + '}';
    }

 
    
}
