/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ico.fes.libro;

import ico.fes.descripcion.Autor;
import ico.fes.descripcion.Editorial;
import libro.Libro;


/**
 *
 * @author arman
 */
public class ReutilizacionCodigoLibro {
    
     public static void main(String[] args) {
         
         Libro libro = new Libro();
         libro.setTitulo("Asunto Pendiente");
         libro.setHojas(448);
         
         Autor nomaut = new Autor();
         nomaut.setNombre("Jhon Katzenbach");
         nomaut.setFoto(true);
         libro.setNomaut(nomaut);
         libro.getNomaut().setFoto(true);
         
         Editorial edit = new Editorial();
         edit.setNombre("Editorial B");
         edit.setLogo(true);
         edit.setAño(2018);
         edit.setUbicacion("Lomas Verdes");
         edit.setLogo(true);
         libro.setEdit(edit);
         //libro.getEdit().setLogo(true); Para qué sirve esto si puedo ponerlo de la otra forma y me imprime lo mismo??
         
         System.out.println(libro);
        
        }
}
