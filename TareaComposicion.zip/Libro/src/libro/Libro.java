/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package libro;

import ico.fes.descripcion.Autor;
import ico.fes.descripcion.Editorial;

/**
 *
 * @author arman
 */
public class Libro {
    private String titulo;
    private int hojas;
    private Autor nomaut;
    private Editorial edit;

    //Constructor
    public Libro() {
    }

    //Constructor sobrecargado
    public Libro(String titulo, int hojas, Autor nomaut, Editorial edit) {
        this.titulo = titulo;
        this.hojas = hojas;
        this.nomaut = nomaut;
        this.edit = edit;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getHojas() {
        return hojas;
    }

    public void setHojas(int hojas) {
        this.hojas = hojas;
    }

    public Autor getNomaut() {
        return nomaut;
    }

    public void setNomaut(Autor nomaut) {
        this.nomaut = nomaut;
    }

    public Editorial getEdit() {
        return edit;
    }

    public void setEdit(Editorial edit) {
        this.edit = edit;
    }

    @Override
    public String toString() {
        return "Libro{" + "titulo=" + titulo + ", hojas=" + hojas + ", nomaut=" + nomaut + ", edit=" + edit + '}';
    }

    
    
    
}
